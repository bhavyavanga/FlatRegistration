package com.capgemini.chennai.bean;

public class FlatDetails {

	private int flatType;
	private long flatArea;
	private long rentAmount;
	private long depositAmount;
	public FlatDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public FlatDetails(int flatType, long flatArea, long rentAmount, long depositAmount) {
		super();
		this.flatType = flatType;
		this.flatArea = flatArea;
		this.rentAmount = rentAmount;
		this.depositAmount = depositAmount;
	}
	public int getFlatType() {
		return flatType;
	}
	public void setFlatType(int flatType) {
		this.flatType = flatType;
	}
	public long getFlatArea() {
		return flatArea;
	}
	public void setFlatArea(long flatArea) {
		this.flatArea = flatArea;
	}
	public long getRentAmount() {
		return rentAmount;
	}
	public void setRentAmount(long rentAmount) {
		this.rentAmount = rentAmount;
	}
	public long getDepositAmount() {
		return depositAmount;
	}
	public void setDepositAmount(long depositAmount) {
		this.depositAmount = depositAmount;
	}
	@Override
	public String toString() {
		return "flatType=" + flatType + ", flatArea=" + flatArea + ", rentAmount=" + rentAmount
				+ ", depositAmount=" + depositAmount;
	}
	
	
	
}
