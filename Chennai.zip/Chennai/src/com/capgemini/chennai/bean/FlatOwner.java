package com.capgemini.chennai.bean;

public class FlatOwner {

	private int flatOwnerId;
	private String flatOwnerName;
	private String mobileNo;
	public FlatOwner() {
		super();
		// TODO Auto-generated constructor stub
	}
	public FlatOwner(int flatOwnerId, String flatOwnerName, String  mobileNo) {
		super();
		this.flatOwnerId = flatOwnerId;
		this.flatOwnerName = flatOwnerName;
		this.mobileNo = mobileNo;
	}
	public int getFlatOwnerId() {
		return flatOwnerId;
	}
	public void setFlatOwnerId(int flatOwnerId) {
		this.flatOwnerId = flatOwnerId;
	}
	public String getFlatOwnerName() {
		return flatOwnerName;
	}
	public void setFlatOwnerName(String flatOwnerName) {
		this.flatOwnerName = flatOwnerName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	@Override
	public String toString() {
		return "flatOwnerId=" + flatOwnerId + ", flatOwnerName=" + flatOwnerName + ", mobileNo=" + mobileNo;
	}
	
}
