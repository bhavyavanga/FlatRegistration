package com.capgemini.chennai.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.capgemini.chennai.bean.FlatDetails;
import com.capgemini.chennai.bean.FlatOwner;

public class FlatRegistrationDaoImpl implements IFlatRegistrationDao {
	List<FlatOwner>list21=new ArrayList();
Map<Integer,FlatOwner>owners=new HashMap();

Map<Integer,FlatOwner> getOwnersEntries(){
owners.put(1, new FlatOwner(1,"Vaishali","9030901533"));

owners.put(2, new FlatOwner(2,"Megha","9876543210"));

owners.put(3, new FlatOwner(3,"Manish","9050953241"));
return owners;
}
	@Override
	public FlatDetails registerFlat(FlatDetails flat) {
		// TODO Auto-generated method stub
		
		return null;
	}

	@Override
	public ArrayList<Integer> getAllOwnersIds() {
		// TODO Auto-generated method stub
		ArrayList<Integer> OwnerIds=new ArrayList<>(getOwnersEntries().keySet());
		/*ArrayList<String> idList=new ArrayList<>(getOwnersEntries().values());
		Iterator<String>iterator= idList.iterator();
		int i=1;
		while(iterator.hasNext()) {
			String catName=iterator.next();
			FlatOwner oi=new FlatOwner(String.valueOf(i),catName);
			OwnerIds.add(oi);
			i++;
		}*/
		return OwnerIds;
	}
	@Override
	public int registrationId() {
		// TODO Auto-generated method stub
		double randomNumber= Math.random()*1000;
		return (int)randomNumber;
	}
	Map<Integer,FlatDetails> flatDetails=new HashMap<>();
	@Override
	public ArrayList<FlatDetails> getFlatDetails() {
		// TODO Auto-generated method stub
		return flatDetails.getOwners;
	}


}
