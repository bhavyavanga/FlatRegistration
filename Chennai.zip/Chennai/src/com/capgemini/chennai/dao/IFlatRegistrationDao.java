package com.capgemini.chennai.dao;

import java.util.ArrayList;

import com.capgemini.chennai.bean.FlatDetails;

public interface IFlatRegistrationDao {

	FlatDetails registerFlat(FlatDetails flat);
	ArrayList<Integer> getAllOwnersIds();
	ArrayList<FlatDetails> getFlatDetails();
	int registrationId();
	
}
