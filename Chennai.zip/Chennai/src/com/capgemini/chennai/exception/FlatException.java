package com.capgemini.chennai.exception;

public class FlatException extends Exception{

	public FlatException() {
		super();
		// TODO Auto-generated constructor stub
	}

}
