package com.capgemini.chennai.service;

import java.util.ArrayList;

import com.capgemini.chennai.bean.FlatDetails;
import com.capgemini.chennai.dao.FlatRegistrationDaoImpl;
import com.capgemini.chennai.dao.IFlatRegistrationDao;

public class FlatRegistrationServiceImpl implements IFlatRegistrationService {
IFlatRegistrationDao flatRegistrationDao= new FlatRegistrationDaoImpl();
	@Override
	public FlatDetails registerFlat(FlatDetails flat) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Integer> getAllOwnersIds() {
		// TODO Auto-generated method stub
		return flatRegistrationDao.getAllOwnersIds();
	}

	@Override
	public int registrationId() {
		// TODO Auto-generated method stub
		return flatRegistrationDao.registrationId();
	}

}
