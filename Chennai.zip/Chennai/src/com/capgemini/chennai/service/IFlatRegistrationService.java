package com.capgemini.chennai.service;

import java.util.ArrayList;

import com.capgemini.chennai.bean.FlatDetails;

public interface IFlatRegistrationService {

	FlatDetails registerFlat(FlatDetails flat);
	ArrayList<Integer> getAllOwnersIds();
	
	int registrationId();
	
}
