package com.capgemini.chennai.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.chennai.bean.FlatDetails;
import com.capgemini.chennai.exception.FlatException;
import com.capgemini.chennai.service.FlatRegistrationServiceImpl;


public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner= new Scanner(System.in);
		FlatRegistrationServiceImpl service = new FlatRegistrationServiceImpl();
		String continueChoice;
		boolean continueValue= false;
		do {
			
			System.out.println("1.Register Flat\n2.Display Flat Registration Details\n3.Exit");
			boolean choiceFlag=false;
			int choice=0;
			do {
				System.out.println("enter input:");
				try {
					choice=scanner.nextInt();
					choiceFlag=true;
					boolean nameFlag=false;
					
					switch (choice) {
					case 1:{
						ArrayList<Integer> list1=service.getAllOwnersIds();
						System.out.println("Existing owner Ids are:-" + list1);
					//	Scanner scanner= new Scanner(System.in);
						System.out.println("enter the id:");
						int id=scanner.nextInt();
						System.out.println("Please enter your Id from above list:"+id);
						System.out.println("enter the flat Type:");
						int flatType=scanner.nextInt();
						System.out.println("SElect flat type(1-1BHK, 2-2BHK:"+flatType);
						System.out.println("enter the flat area:");
						long flatArea=scanner.nextInt();
						System.out.println("Enter flat area in sq.ft:"+flatArea);
						System.out.println("enter the rent amount:");
						long rentAmount=scanner.nextInt();
						System.out.println("Enter desired rent amount Rs:"+rentAmount);
						System.out.println("enter the deposit amount");
						long depositAmount=scanner.nextInt();
						System.out.println("Enter desired deposit amount Rs:"+depositAmount);
						int registrationId=service.registrationId();
						FlatDetails flatDetails=new FlatDetails(flatType,flatArea,rentAmount,depositAmount);
						System.out.println("Flat successfully registered. Registration id:<"+registrationId+">");
					}break;
					case 2:
						
					}
						
					
				}catch(InputMismatchException exception){
					choiceFlag=true;
					System.out.println("input should be in digits");
				}
			}while(!choiceFlag);
		
			do {
				System.out.println("do you want to continue again[yes/no]");
				continueChoice=scanner.next();
				if(continueChoice.equalsIgnoreCase("yes")) {
					continueValue=true;
					break;
				}
				else if(continueChoice.equalsIgnoreCase("no")){
					System.out.println("Thank You");
					continueValue=false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue=false;
					break;
				}
			}while(!continueValue);
		}while(continueValue);
		scanner.close();
	}

}
